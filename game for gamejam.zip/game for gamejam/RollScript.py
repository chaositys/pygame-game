
import random
import time
import convertFile
class roll():
    def choose_roll_type():
        roll_type = input("Do you want hot rolls or cold rolls? Type 'hot' or 'cold': ").lower()
        while roll_type not in ['hot', 'cold']:
            print("Invalid choice. Please type 'hot' or 'cold'.")
            roll_type = input("Do you want hot rolls or cold rolls? Type 'hot' or 'cold': ").lower()
        return roll_type

   

    def roll_cold_temperature():
 
        cold_probabilities = {
            "Subzero": 1 / (2 ** 30),
            "Subfreezing": 1 / (2 ** 29),
            "Frigid": 1 / (2 ** 28),
            "Freezing": 1 / (2 ** 27),
            "Bracing": 1 / (2 ** 26),
            "Frosty": 1 / (2 ** 25),
            "Colder than ice": 1 / (2 ** 24),
            "Cold as Ice": 1 / (2 ** 23),
            "Ice-cold": 1 / (2 ** 22),
            "Glacial": 1 / (2 ** 21),
            "Arctic": 1 / (2 ** 20),
            "Polar": 1 / (2 ** 19),
            "Frozen": 1 / (2 ** 18),
            "Bitter": 1 / (2 ** 17),
            "Chilly": 1 / (2 ** 16),
            "Cool": 1 / (2 ** 15),
            "Brisk": 1 / (2 ** 14),
            "Icy": 1 / (2 ** 13),
            "Biting": 1 / (2 ** 12),
            "Cold": 1 / (2 ** 11),
            "Rather Chilly": 1 / (2 ** 10),
            "Coldish": 1 / (2 ** 9),
            "Not So Cold": 1 / (2 ** 8),
            "Still Not Warm": 1 / (2 ** 7),
            "Not Quite Cool": 1 / (2 ** 6),
            "Chilly": 1 / (2 ** 5),
            "Chill": 1 / (2 ** 4),
            "Like 20 C": 1 / (2 ** 3),
            "Almost mild": 1 / (2 ** 2),
            "Mild": 1 / (2 ** 1)
        }
        
        cold_temperature = random.choices(list(cold_probabilities.keys()), list(cold_probabilities.values()))[0]
        
        probability_percent = cold_probabilities[cold_temperature] * 100
        
        
        
        return cold_temperature, probability_percent



    

    def roll_hot_temperature(num):
        num = num / 100

        hot_probabilities = {
            "Ton 618 accretion disk": (num * 100) / (2 ** 35),
            "Phoenix A accretion disk": (num * 50) / (2 ** 32),
            "Sagittarius A accretion disk": (num * 25) / (2 ** 30),
            "UY Scuti": (num * 23) / (2 ** 29),
            "THE SUN BUT HOTTER BUT EVN HOTTER": (num * 22) / (2 ** 28),
            "THE SUN BUT HOTTER": (num * 20) / (2 ** 27),
            "THE SUN": (num * 18) / (2 ** 26),
            "Earths core": (num * 16) / (2 ** 25),
            "Scorching": (num * 15) / (2 ** 23),
            "Burning": (num * 12) / (2 ** 22),
            "Roasting": (num * 11) / (2 ** 21),
            "Boiling": (num * 11) / (2 ** 19),
            "Scaldering": (num * 10) / (2 ** 18),
            "Balmy": (num * 7) / (2 ** 17),
            "Sweltering": (num * 5) / (2 ** 16),
            "Sizzling": (num * 5) / (2 ** 15),
            "Blazing": (num * 4.5) / (2 ** 13),
            "Infernal": (num * 3.3) / (2 ** 11),
            "Hellish": (num * 2) / (2 ** 10),
            "Tropical": (num * 1.5) / (2 ** 6),
            "Searing": (num * 1.4) / (2 ** 5),
            "Sultry": num / (2 ** 4),
            "Steamy": num / (2 ** 3),
            "Hot": num / (2 ** 2),
            "Temperate": num / (2 ** 1),
        }

        for key in hot_probabilities:
            hot_probabilities[key] *= (1 + num)
        
        filtered_probabilities = {}
        for temperature, probability in hot_probabilities.items():
            if probability <= 1:  # Converting to percentage, so maximum should be 1 (100%)
                filtered_probabilities[temperature] = probability
        try:
            hot_temperature = random.choices(list(filtered_probabilities.keys()), list(filtered_probabilities.values()))[0]

            probability_percent = filtered_probabilities[hot_temperature] * 100

            return hot_temperature, probability_percent
        except IndexError:
            print("")
            print("")
            print("")
            print("")
            print("!!!!!!!!!!!!!!! YOU WON !!!!!!!!!!!!!!!!")
            print("")
            print("")
            print("")
            print("")
            return quit()

            

    def main():
        roll_type = roll.choose_roll_type()
        print(f"You have chosen {roll_type} rolls.")
        if roll_type == 'hot':
            while True:
                input("Press Enter to roll the temperature aura...")
                hot_temperature_aura = roll.roll_hot_temperature()
                print("Hot Temperature Aura:", hot_temperature_aura)
                time.sleep(0.8)
        else:
            while True:
                input("Press Enter to roll the temperature aura...")
                cold_temperature_aura = roll.roll_cold_temperature()
                print("Cold Temperature Aura:", cold_temperature_aura)
                time.sleep(0.8)

if __name__ == "__main__":
    roll.main() 