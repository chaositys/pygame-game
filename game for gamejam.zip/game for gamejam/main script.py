import pygame
from pygame.locals import *
import random
import RollScript as RS
import convertFile
import time as T

class Game:
    @staticmethod
    def draw_button(screen, x, y, width, height, text):
        button_font = pygame.font.Font(None, 36)
        button_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(screen, (0, 255, 0), button_rect)
        
        text_surface = button_font.render(text, True, (0, 0, 0))
        text_rect = text_surface.get_rect(center=button_rect.center)
        screen.blit(text_surface, text_rect)
        
        return button_rect
    
            
    def screen(self):
        pygame.init()
        def change_volume(volume_level,sound):
            sound.set_volume(volume_level)
        screen = pygame.display.set_mode((1000,800))
        pygame.display.set_caption("SJ RNG")
        running = True
        font = pygame.font.Font(None, 36)
        font2 = pygame.font.Font(None,80)
        WHITE = (255, 255, 255)
        BLACK = (0, 0, 0)
        
        rarest_file_hot = open("rarest_hot.txt","r")
        luckestpercent_hot = str(rarest_file_hot.read())
        rarest_file_hot.close()
        rarest_file_text_hot = open("rarest_text_hot.txt","r")
        luckest_hot = str(rarest_file_text_hot.read())
        rarest_file_text_hot.close()
        if luckest_hot == "":
            luckest_hot = "Not Rolled"
        Roll_Click = pygame.mixer.Sound("luck_roll.wav")
        volume = Roll_Click.get_volume()
        
        
        rarest_file_cold = open("rarest_cold.txt","r")
        luckestpercent_cold = str(rarest_file_cold.read())
        rarest_file_cold.close()
        rarest_file_text_cold = open("rarest_text_cold.txt","r")
        luckest_cold = str(rarest_file_text_cold.read())
        rarest_file_text_cold.close()
        if luckest_cold == "":
            luckest_cold = "Not Rolled"
        
        hot_clicked = False
        num_cold = ""
        chance_of_roll_cold = ""
        num_hot = ""
        chance_of_roll_hot = ""
        test123_hot = False
        test123_cold = False
        clicked_first_hot = False
        clicked_first_cold = False
        with open("percentMultiHot.txt") as PMH:
            
            hot_percent = str(PMH.read())
            hot_percent = float(hot_percent)
        with open("percentMultiCold.txt") as PMC:
            
            cold_percent = str(PMC.read())
            cold_percent = int(cold_percent)
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.draw_button(screen, 600, 340, 100, 50, "Hot Luck").collidepoint(event.pos):
                        pygame.mixer.Sound.play(Roll_Click)
                        test123_hot = True
                        num_hot,chance_of_roll_hot = RS.roll.roll_hot_temperature(hot_percent)
                        clicked_first_hot = True
                        hot_clicked = True
                        if float(chance_of_roll_hot) <float(luckestpercent_hot):
                            luckestpercent_hot = chance_of_roll_hot
                            try:
                                with open("rarest_hot.txt","w") as rarest_file_hot:
                                    rarest_file_hot.write(str(luckestpercent_hot))
                                
                                    luckest_hot = num_hot
                            except PermissionError as p:
                                print(f"Permission Error {p}")
                            try:
                                with open("rarest_text_hot.txt","w")  as rarest_file_text_hot:
                                
                                    rarest_file_text_hot.write(str(luckest_hot))
                            except PermissionError as p:
                                print(f"Permission Error {p}")
                               
                            
                    elif self.draw_button(screen, 200, 340, 100, 50, "Cold Luck").collidepoint(event.pos):
                        pygame.mixer.Sound.play(Roll_Click)
                        test123_cold = True
                        num_cold,chance_of_roll_cold = RS.roll.roll_cold_temperature()
                        clicked_first_cold = True
                        if float(chance_of_roll_cold) <float(luckestpercent_cold):
                            luckestpercent_cold = chance_of_roll_cold
                            with open("rarest_cold.txt","w") as rarest_file_cold :
                                
                                rarest_file_cold.write(str(luckestpercent_cold))
                                
                                luckest_cold = num_cold
                            with  open("rarest_text_cold.txt","w") as rarest_file_text_cold:
                                rarest_file_text_cold.write(str(luckest_cold))
                                
                            
                    elif self.draw_button(screen,600,140,100,50,"Hot Convert").collidepoint(event.pos):
                        
                        
                        hot_percent += convertFile.placeholder("hot",luckest_hot)
                        with open("percentMultiHot.txt","w") as PMH:
                            
                            PMH.write(str(hot_percent))
                        luckest_hot = ""
                        luckestpercent_hot = 100
                        try:
                            with open("rarest_hot.txt","w")as rarest_file_hot :
                                rarest_file_hot.write(str(100))
                        except PermissionError as p:
                                print(f"Permission Error {p}")
                            
                        try:   
                            with open("rarest_text_hot.txt","w") as rarest_file_text_hot :
                                rarest_file_text_hot.write(str(""))
                        except PermissionError as p:
                                print(f"Permission Error {p}")
                            
                        
                    #elif self.draw_button(screen,200,140,100,50,"cold convert").collidepoint(event.pos):
                       # cold_percent += convertFile.placeholder("cold",luckest_cold)
                       # luckest_cold = ""
                       # luckestpercent_cold = 100
                       # 
                       # with open("rarest_cold.txt","w")as rarest_file_cold:
                       #     rarest_file_cold.write(str(100))
                       # 
                       # with open("rarest_text_cold.txt","w") as rarest_file_text_cold:
                       #     
                       #     rarest_file_text_cold.write(str(""))
                        
                elif event.type == pygame.KEYDOWN:
                    print("test 1")
                    if event.key == pygame.K_i:
                        print("test 2")
                        volume += 0.1
                        
                        if volume >1.0:  
                            volume = 1.0
                            print("test 4")
                        change_volume(volume,Roll_Click)
                        
                        
                    elif event.key == pygame.K_o:
                        print("test 3")
                        volume -= 0.1
                        
                        if volume < 0.0:  
                            volume = 0.0
                            print("test 5")
                        change_volume(volume,Roll_Click)
                        
                            
            screen.fill(WHITE)
          #  self.draw_button(screen,200, 340, 100, 50, "cold Luck")
           # if hot_clicked == True:
            #    
             #   luckest_text_cold = font.render(f"Your Luckest Roll: {luckest_cold}", True, BLACK)
                #luckest_text_percent_cold = font.render(f"{luckestpercent_cold}%", True, BLACK)
              #  screen.blit(luckest_text_cold, (100, 560))
              #  screen.blit(luckest_text_percent_cold, (100, 590))
              #  if clicked_first_cold == True:
               #     num_text_cold = font.render(f"{num_cold}", True, BLACK)
                #    chance_text_cold = font.render(f"{chance_of_roll_cold}%",True,BLACK)
                    
                    
                  #  screen.blit(num_text_cold, (100, 500))
                  #  screen.blit(chance_text_cold, (100, 530))
                  #  screen.blit(luckest_text_cold, (100, 560))
                 #   screen.blit(luckest_text_percent_cold, (100, 590))
                 #   
          #  cold_percent_luck = font.render(f"{cold_percent}%", True, BLACK)
         #   screen.blit(cold_percent_luck, (200, 40))
         #   hot_percent_luck = font.render(f"{hot_percent}%", True, BLACK)
         #   screen.blit(hot_percent_luck, (600, 40))
            self.draw_button(screen,600, 340, 100, 50, "Hot Luck")
            
            
            self.draw_button(screen,600,140,100,50,"Hot Convert")
            
   #         self.draw_button(screen,200,140,100,50,"Cold Convert")
            
            
            
            
            luckest_text_hot = font.render(f"Your Luckest Roll: {luckest_hot}", True, BLACK)
            luckest_text_percent_hot = font.render(f"{luckestpercent_hot}%", True, BLACK)
            screen.blit(luckest_text_hot, (500, 560))
            screen.blit(luckest_text_percent_hot, (500, 590))
            if test123_hot == True:
                
                screen.blit(font2.render(".",True,BLACK),(630,460)),T.sleep(0),pygame.display.update()
                screen.blit(font2.render("..",True,BLACK),(630,460)),T.sleep(0),pygame.display.update()
                screen.blit(font2.render("...",True,BLACK),(630,460)),T.sleep(0),pygame.display.update()
                screen.blit(font2.render("....",True,BLACK),(630,460)),T.sleep(0),pygame.display.update()
                test123_hot = False
                hot_clicked= False
                
            if clicked_first_hot == True:
                num_text_hot = font.render(f"{num_hot}", True, BLACK)
                chance_text_hot = font.render(f"{chance_of_roll_hot}%",True,BLACK)
                
                
                screen.blit(num_text_hot, (500, 500))
                screen.blit(chance_text_hot, (500, 530))
                screen.blit(luckest_text_hot, (500, 560))
                screen.blit(luckest_text_percent_hot, (500, 590))
                
                
        #    self.draw_button(screen,200, 340, 100, 50, "cold Luck")
            
            
         #   luckest_text_cold = font.render(f"Your Luckest Roll: {luckest_cold}", True, BLACK)
         ##   luckest_text_percent_cold = font.render(f"{luckestpercent_cold}%", True, BLACK)
          #  screen.blit(luckest_text_cold, (100, 560))
           # screen.blit(luckest_text_percent_cold, (100, 590))
           # if test123_cold == True:
                
              #  screen.blit(font2.render(".",True,BLACK),(230,460)),T.sleep(0.1),pygame.display.update()
                #screen.blit(font2.render("..",True,BLACK),(230,460)),T.sleep(0.1),pygame.display.update()
               # screen.blit(font2.render("...",True,BLACK),(230,460)),T.sleep(0.1),pygame.display.update()
               # screen.blit(font2.render("....",True,BLACK),(230,460)),T.sleep(0.1),pygame.display.update()
               # test123_cold = False
                
          #  if clicked_first_cold == True:
           #     num_text_cold = font.render(f"{num_cold}", True, BLACK)
            #    chance_text_cold = font.render(f"{chance_of_roll_cold}%",True,BLACK)
                
                
              #  screen.blit(num_text_cold, (100, 500))
           #     screen.blit(chance_text_cold, (100, 530))
             #   screen.blit(luckest_text_cold, (100, 560))
              #  screen.blit(luckest_text_percent_cold, (100, 590))
            
            
            
            
            
            
            
            
            
            
            
            pygame.display.update()
            
if __name__ == "__main__":
    Gameinstance = Game()
    Gameinstance.screen()
