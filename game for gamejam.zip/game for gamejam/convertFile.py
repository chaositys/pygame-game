import random
import math
def placeholder(temp,item):
    cold_list = ["Subzero",
            "Subfreezing",
            "Frigid",
            "Freezing",
            "Bracing",
            "Frosty",
            "Colder than ice",
            "Cold as Ice",
            "Ice-cold",
            "Glacial",
            "Arctic",
            "Polar",
            "Frozen",
            "Bitter",
            "Chilly",
            "Cool",
            "Brisk",
            "Icy",
            "Biting",
            "Cold",
            "Rather Chilly",
            "Coldish",
            "Not So Cold",
            "Still Not Warm",
            "Not Quite Cool",
            "Chilly",
            "Chill",
            "Like 20 C",
            "Almost mild",
            "Mild"]
    hot_list = ["Ton 618 accretion disk",
            "Phoenix A accretion disk",
            "Sagittarius A accretion disk",
            "UY Scuti",
            "THE SUN BUT HOTTER BUT EVN HOTTER",
            "THE SUN BUT HOTTER",
            "THE SUN",
            "Earths core",
            "Scorching",
            "Burning",
            "Roasting",
            "Boiling",
            "Scaldering",
            "Balmy",
            "Sweltering",
            "Sizzling",
            "Blazing",
            "Infernal",
            "Hellish",
            "Tropical",
            "Searing",
            "Sultry",
            "Steamy",
            "Hot",
            "Temperate"]
    if temp == "hot":
        i = 0
        q = 4000
        while  True:
            if item != "" and item != "Not Rolled":
                
                if item == hot_list[i]:
                    
                    q =  round(q * 5) / 5
                    if i == 0 :
                        print("you win")
                    
                    return q
                    
                elif i > 20:
                    i+=1
                    q-=0.2
                elif i > 16:
                    i+=1
                    q-=1
                elif i > 12:
                    i+=1
                    q-=5.19
                elif i > 7:
                    i+=1
                    q-=95
                elif i > 3:
                    i+=1
                    q-=200
                elif i > 0:
                    i+=1
                    q-=566.48
                elif i == 0:
                    i+=1
                    q-=1000
                    
                
            else:
                return 0
    elif temp == "cold":
        i = 0
        q = 0
        while  True:
            
            if item != ""and item != "Not Rolled":
                if item == cold_list[i] :
                    return q
                    
                elif i > 22:
                    i+=1
                    q+=1
                elif i > 16:
                    i+=1
                    q+=5.22
                elif i > 10:
                    i+=1
                    q+=100
                elif i > 6:
                    i+=1
                    q+=200
                elif i > 1:
                    i+=1
                    q+=10000
                else:
                    i+=1
                    q+=0.2
            else:
                return 0
if __name__ == "__main__":
    placeholder()